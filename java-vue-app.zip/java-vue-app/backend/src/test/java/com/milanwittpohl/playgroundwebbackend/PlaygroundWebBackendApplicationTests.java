package com.milanwittpohl.playgroundwebbackend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PlaygroundWebBackendApplicationTests {

    @Test
    void contextLoads() {
    }
}
